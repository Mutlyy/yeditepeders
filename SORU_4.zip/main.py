x=input("Lütfen bir adinizi giriniz : ")
print(x[1:4])







