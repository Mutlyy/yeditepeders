x=input("Bir sözcük giriniz : ")
for harf in x :
  print(harf + "!")