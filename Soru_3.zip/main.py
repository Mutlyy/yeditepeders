x=input("lütfen bir sözcük giriniz :")
print(x[0] + x[-1])


