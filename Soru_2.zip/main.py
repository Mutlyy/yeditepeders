x=input("lütfen adinizi giriniz :")
y=input("lütfen soyadinizi giriniz :")
sonuc = x[0] +"." + y[0]
print(sonuc)
