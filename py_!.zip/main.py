#toplam=0
#soru2=int(input("Kaca kadar sayı alsın? : "))
#for x in range(soru2) :
  #soru=int(input(str(x+1)+". sayi giriniz : "))
  #toplam+=soru
  
#print(toplam)

x=int(input("X-Koordinate"))
y=int(input("X-Koordinate"))
t=x+y
if t%2==0 :
  print("Schwarz")
else :
  print("Weiss")
  