x=input("Bir sözcük giriniz :")
print(len(x))

















